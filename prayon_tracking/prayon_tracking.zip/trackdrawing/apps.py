from django.apps import AppConfig


class TrackdrawingConfig(AppConfig):
    name = 'trackdrawing'
